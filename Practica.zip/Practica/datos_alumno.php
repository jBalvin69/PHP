<?php
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$matricula = $_POST['matricula'];
$op = $_POST['op'];
$mostrar = $_POST['datos'];
$m;
 
if (trim($nombre) == '') {
    echo'<script type="text/javascript">
    alert("El nombre esta vacío");
    window.location.href="datos_alumno.html";

    </script>';
}

if (trim($telefono) == '') {
    echo'<script type="text/javascript">
    alert("El teléfono esta vacío");
    window.location.href="datos_alumno.html";

    </script>';
}

if (!is_numeric($telefono)){
    echo'<script type="text/javascript">
    alert("El teléfono solo debe tener caracteres numéricos");
    window.location.href="datos_alumno.html";

    </script>';
}

if ($matricula == 'si') {
    if ($mostrar=='pantalla'){
    echo "el alumno ".  $nombre ." con teléfono ". $telefono .",está matriculado en ".$op;
}
if ($mostrar=='archivo'){
    $file="datos.txt";
    $archivo=fopen($file,"w");
    fwrite($archivo,"el alumno ".  $nombre ." con telefono ". $telefono .",esta matriculado en ".$op);
    echo'
    <a href="./mostrardatos.php">mostrar archivo</a>';
    fclose($archivo);
}
 }
 
if ($matricula != 'si'){
    if ($mostrar=='pantalla'){
    echo "el alumno ".  $nombre ." con teléfono ". $telefono .", no está matriculado en ningún curso";
}
if ($mostrar=='archivo'){
    $file="datos.txt";
    $archivo=fopen($file,"w");
    fwrite($archivo,"el alumno ".  $nombre." con telefono ". $telefono.", no esta matriculado en ningun curso");
    echo'
    <a href="./mostrardatos.php">Mostrar archivo</a>';
    fclose($archivo);
}
}
 
 
?>
 