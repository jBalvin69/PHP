<?php
$num=0;
$num2=0;
print "<h1>Jugador 1</h1>";
for ($i=0; $i<6; $i++) {
    $dado=rand(1,6);
    $num1=$num1+$dado;
    print "<img src='./img/$dado.jpg'></img>";
}
echo "<br><h1>Puntos: $num1 <br><br>";

print "<h1>Jugador 2</h1>";
for ($i=0; $i<6; $i++) {
    $dado2=rand(1,6);
    $num2=$num2+$dado2;
    print "<img src='./img/$dado2.jpg'></img>";
}
echo "<br><h1>Puntos: $num2 <br><br>";



if ($num1>$num2){
    echo "<h1>En el global ha ganado el Jugador 1</h1>";
}
if ($num2>$num1){
    echo "<h1>En el global ha ganado el Jugador 2</h1>";
}
if ($num1==$num2){
    echo "<h1>ha habido un empate</h1>";
}

?>
